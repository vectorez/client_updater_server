<?php
/**
 * @license MIT <http://opensource.org/licenses/MIT>
 */

return [
	'githubWebhookSecret' => 'thisIsTheGithubWebhookSecret',
	'githubWebhookBranch' => 'master',
];
